/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views.Decorations;

import java.awt.Color;

/**
 *
 * @author GerardoAGL
 */
public class Colors {
    
    public static Color red(){
        
        return new Color(213, 0, 0);
    }
    
    public static Color lightBlue(){
        
        return new Color(0,145,234);
    }
    
    public static Color green(){
        
        return new Color(67, 160, 71);
    }
    
    public static Color grey(){
        
        return new Color(117, 117, 117);
    }
}
